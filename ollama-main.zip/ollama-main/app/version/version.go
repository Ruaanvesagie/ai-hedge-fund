//go:build windows || darwin

package version

var Version string = "0.0.0"
