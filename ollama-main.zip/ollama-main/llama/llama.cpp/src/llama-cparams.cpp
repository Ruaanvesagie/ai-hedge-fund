#include "llama-cparams.h"

size_t llama_max_parallel_sequences(void) {
    return LLAMA_MAX_SEQ;
}
